let items=JSON.parse(localStorage.getItem("palaceMenu")||'[]');
if(!items.length){items=[
{name:"Carré d’agneau",cat:"Plats",price:2400},{name:"Filet de poisson",cat:"Plats",price:2200},
{name:"Risotto du Palace",cat:"Plats",price:1900},{name:"Dessert signature",cat:"Desserts",price:900}]}
function save(){localStorage.setItem("palaceMenu",JSON.stringify(items));render()}
function render(){document.getElementById("menu").innerHTML=items.map((x,i)=>`<div class="item"><input value="${x.name}" onchange="items[${i}].name=this.value;save()"><input value="${x.cat}" onchange="items[${i}].cat=this.value;save()"><input class="price" type="number" value="${x.price}" onchange="items[${i}].price=+this.value;save()"><button onclick="items.splice(${i},1);save()">Supprimer</button></div>`).join("")}
function add(){const name=document.getElementById("name").value,cat=document.getElementById("cat").value||"Plats",price=+document.getElementById("price").value;if(!name||!price)return alert("Indiquez le nom et le prix.");items.push({name,cat,price});save()}
render();
const t=document.getElementById("tables"); for(let i=1;i<=20;i++){const n=String(i).padStart(2,"0");const url=encodeURIComponent(`https://www.resto-palace.dz/table/${n}`);t.innerHTML+=`<div class="table"><b>Table ${n}</b><img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${url}" alt="QR Table ${n}"><small>Scanner pour commander</small></div>`}
document.getElementById("ordersCount").textContent="2";
